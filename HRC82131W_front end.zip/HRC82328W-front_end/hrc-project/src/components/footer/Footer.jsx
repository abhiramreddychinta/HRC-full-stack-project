import React from 'react'
import './footer.css'

export default function Footer() {
  return (
    <div id='footer-container'>

    <p id='footer-text'>
       Privacy Policy | 2022 HighRadius Corporation. All rights Reserved.
    </p>

    </div>
  )
}

