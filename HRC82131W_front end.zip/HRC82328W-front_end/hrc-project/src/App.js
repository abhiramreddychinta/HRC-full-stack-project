import logo from './logo.svg';
import './App.css';
import Header from './components/header/Header';
import Crud from './components/Crud/Crud';
import Table from './components/Table/Table';
import Footer  from './components/footer/Footer';
import MyGrid from './MyGrid';
import MyGrid1 from './MyGrid1';
function App() {
  return (
    <div className="App">
      {/* <Header/>
      <Crud />
      <Table />

      <Footer />      */}

      <MyGrid />


    </div>
  );
}

export default App;
